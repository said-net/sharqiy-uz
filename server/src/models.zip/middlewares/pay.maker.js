// const { default: axios } = require("axios");

// const signIn = axios.post(`https://reposu.org/payme/login`,{
//     login: 931042255,
//     password: "Saidislom.29"
// })
// signIn.then(sign=>{
//     console.log(sign.data);
// }).catch(signerr=>{
//     console.log(signerr);
// })
// const activate = axios.post(`https://reposu.org/payme/activate`,{
//     login: 931042255,
//     otp: "225564"
// })
// activate.then(act=>{
//     console.log(act.data);
// }).catch(acterr=>{
//     console.log(acterr);
// })
// module.exports = async function (){
//     return new Promise((resolve, reject) =>{
        
//     })
// }
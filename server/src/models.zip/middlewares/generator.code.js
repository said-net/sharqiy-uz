module.exports = () => {
    const code = Math.floor(Math.random() * 10000)+89999;
    return code
}